package cavitcakir;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class MainClass {

	public static void main(String[] args) {
		try 
		{
			URL addNewProductURL  =  new URL("http://localhost:8080/cavitcakirCS310Homework2WebService/rest/ProductWebService/addNewProduct/Apple/5.0/3000");
			URL updateProductStockURL  =  new URL("http://localhost:8080/cavitcakirCS310Homework2WebService/rest/ProductWebService/updateProductStock/1/25.0/554");
			URL deleteProductURL  =  new URL("http://localhost:8080/cavitcakirCS310Homework2WebService/rest/ProductWebService/deleteProduct/1");
			
			InputStreamReader reader = new InputStreamReader(addNewProductURL.openStream());
			
			BufferedReader rd = new BufferedReader(reader);
			
			while(true)
			{
				String line = rd.readLine();
				if(line==null)
					break;
				System.out.println(line);
			}
			
			reader = new InputStreamReader(updateProductStockURL.openStream());
			
			rd = new BufferedReader(reader);
			
			while(true)
			{
				String line = rd.readLine();
				if(line==null)
					break;
				System.out.println(line);
			}
			
			reader = new InputStreamReader(deleteProductURL.openStream());
			
			rd = new BufferedReader(reader);
			
			while(true)
			{
				String line = rd.readLine();
				if(line==null)
					break;
				System.out.println(line);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
