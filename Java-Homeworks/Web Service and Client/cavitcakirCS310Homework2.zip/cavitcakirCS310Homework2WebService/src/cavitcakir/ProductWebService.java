package cavitcakir;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/ProductWebService")
public class ProductWebService {
	
	@GET
	@Path("/addNewProduct/{n}/{p}/{s}")
	public boolean addProduct( @PathParam("n") String name, @PathParam("p") double price, @PathParam("s") int stock) {
		Product prod = new Product(name, price, stock);
		boolean result = CavitJDBCManager.save(prod); 
		return result;
	}

	@GET
	@Path("/deleteProduct/{id}")
	public boolean deleteProdut(@PathParam("id") int id) {
		boolean result = CavitJDBCManager.delete(id); 
		return result;
	}
	
	@GET
	@Path("/updateProductStock/{id}/{p}/{s}")
	public boolean updateProdut( @PathParam("id") int id, @PathParam("p") double price, @PathParam("s") int stock) {
		boolean result = CavitJDBCManager.update(id, price, stock); 
		return result;
	}
}
