package cavitcakir;

public class CreateDB {

	public static void main(String[] args) 
	{
		CavitJDBCManager.createDB();
	}
}
