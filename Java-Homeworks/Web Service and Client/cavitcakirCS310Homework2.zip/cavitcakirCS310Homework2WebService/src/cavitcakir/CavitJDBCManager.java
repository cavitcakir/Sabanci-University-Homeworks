package cavitcakir;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import cavitcakir.Product;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CavitJDBCManager {
	
	public static void createDB() {
		String sql = "CREATE TABLE product (" +
				"id int NOT NULL AUTO_INCREMENT, " +
                " name VARCHAR(255), " + 
                " price DOUBLE, " +
                " stock INT, " +
                " PRIMARY KEY (id))";
		
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/cs310", "root", "123123123");
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("Table created!!!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean save(Product p1) 
	{
		try 
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/cs310", "root", "123123123");
			java.sql.PreparedStatement ps =  con.prepareStatement("insert into product (name, price, stock) values (?,?,?)");
			ps.setString(1, p1.getName());
			ps.setDouble(2, p1.getPrice());
			ps.setInt(3, p1.getStock());
			int result = ps.executeUpdate();
			
			if(result==1)
			{
				System.out.println("data inserted.");
				return true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean delete (int id) {
		try
		{
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/cs310", "root", "123123123");	
			PreparedStatement ps =  connection.prepareStatement("DELETE FROM product WHERE id=?");
			ps.setInt(1, id);
			int rs = ps.executeUpdate();
			if(rs!=0) {
				System.out.println("deleted");
				connection.close();
				return true;
			}
			else {
				System.out.println("cannot find");
				connection.close();
				return false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
		
	}
	
	public static boolean update (int id, double price, int stock) {
		try
		{
			Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/cs310", "root", "123123123");	
			PreparedStatement ps =  connection.prepareStatement("update product set price=?,stock=? where id=? ");
			ps.setDouble(1, price);
			ps.setInt(2, stock);
			ps.setInt(3, id);
			int rs = ps.executeUpdate();
			if(rs!=0) {
				System.out.println("deleted");
				connection.close();
				return true;
			}
			else {
				System.out.println("cannot find");
				connection.close();
				return false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static ArrayList<Product> getAll() {
		ArrayList<Product> prods = new ArrayList<Product>();
		try 
		{
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/cs310", "root","123123123");
			PreparedStatement ps =  con.prepareStatement("select * from product");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				int i = rs.getInt("id");
				String n = rs.getString("name");
				double p = rs.getDouble("price");
				int s = rs.getInt("stock");
				Product e = new Product(n, p, s);
				e.setId(i);
				
				prods.add(e);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return prods;
	}
}
