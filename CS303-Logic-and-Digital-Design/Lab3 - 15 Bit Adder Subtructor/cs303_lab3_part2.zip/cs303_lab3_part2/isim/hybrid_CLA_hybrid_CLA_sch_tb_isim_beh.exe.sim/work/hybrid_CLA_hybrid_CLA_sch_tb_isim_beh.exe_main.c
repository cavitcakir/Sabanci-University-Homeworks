/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    unisims_ver_m_00000000002549801008_4245414866_init();
    unisims_ver_m_00000000003510477262_2316096324_init();
    unisims_ver_m_00000000003149700083_1668249201_init();
    unisims_ver_m_00000000002123152668_0970595058_init();
    unisims_ver_m_00000000001162476414_1323117156_init();
    unisims_ver_m_00000000001762375489_3501834183_init();
    work_m_00000000003308399648_1029756224_init();
    unisims_ver_m_00000000000924517765_3125220529_init();
    work_m_00000000004064415366_2465206804_init();
    work_m_00000000002645316654_2680624506_init();
    work_m_00000000002964766653_4121615308_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002964766653_4121615308");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
